def load_menu(filename):
    menu = {} # menu is a dictionary
    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            if len(parts) == 3:
                item_id, name, price = parts
                menu[item_id] = {"name": name, "price": float(price)} 
              # menu[key] = {"name": "Burger", "price": 99.0} 
              # key       = Values stores in another dictionary
    return menu 
    print(menu)
  
def display_menu(menu):
    # TODO: Print menu with headers (ID, Name, Price)
    print(f"{'ID':<10}{'Name':<20}{'Price':<30}") # "<" means left-align; 10,20,30 are width of columns 
    print("_" * 50)
    for item_id, food in menu.items(): # item_id is the key (for eg, "1")
        name = food["name"]            # food is the value that is another nested dictionary {"name": "Burger", "price": 99.0} 
        price = food["price"]       # extracts name and price from nested dictionary
        print(f"{item_id:<10}{name:<20} ₹ {price:<30}")
    pass

# important Note

# What does menu.items() mean? The word items is a method name, not a variable
# menu is a dictionary.

# menu.items() returns a view of the dictionary’s key-value pairs as tuples.
# Example:
# menu = {
#    "1": {"name": "Burger", "price": 99},
#    "2": {"name": "Pizza", "price": 149}        }

# menu.items() → [('1', {'name': 'Burger', 'price': 99}), ('2', {'name': 'Pizza', 'price': 149})]
# menu.items is necessary here as it gives (key, value)
# menu.keys() gives only keys
# menu.values() gives only values