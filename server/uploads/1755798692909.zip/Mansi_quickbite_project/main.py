from menu import load_menu, display_menu
from billing import calculate_total
from utils import save_order

def main():
    menu = load_menu("data/menu.txt")
    display_menu(menu)

    order = []
    while True:
        item_id = input("Enter item ID (or 'q' to quit): ")
        if item_id.lower() == 'q':
            break
        quantity = input("Enter quantity: ")

        try:
            quantity = int(quantity)
            order.append((item_id, quantity))
        except ValueError:
            print("Invalid quantity. Please enter a number.")
    # print(order)        

    total = calculate_total(order, menu)
    print(f"\n🧾 Total Bill: ₹ {total}")
    save_order(order, total, "data/orders.txt", menu)

if __name__ == "__main__":
    main()
